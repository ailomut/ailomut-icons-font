// Place fonts/ailomut-icons.ttf in your fonts/ directory and
// add the following to your pubspec.yaml
// flutter:
//   fonts:
//    - family: ailomut-icons
//      fonts:
//       - asset: fonts/ailomut-icons.ttf
import 'package:flutter/widgets.dart';

class Ailomut_icons {
  Ailomut_icons._();

  static const String _fontFamily = 'ailomut-icons';

  static const IconData archway_outline = IconData(0xe900, fontFamily: _fontFamily);
  static const IconData building_outline = IconData(0xe901, fontFamily: _fontFamily);
  static const IconData campground_outline = IconData(0xe902, fontFamily: _fontFamily);
  static const IconData car_building_outline = IconData(0xe903, fontFamily: _fontFamily);
  static const IconData chimney_outline = IconData(0xe904, fontFamily: _fontFamily);
  static const IconData church_outline = IconData(0xe905, fontFamily: _fontFamily);
  static const IconData city_outline = IconData(0xe906, fontFamily: _fontFamily);
  static const IconData clinic_medical_outline = IconData(0xe907, fontFamily: _fontFamily);
  static const IconData container_storage_outline = IconData(0xe908, fontFamily: _fontFamily);
  static const IconData dungeon_outline = IconData(0xe909, fontFamily: _fontFamily);
  static const IconData farm_outline = IconData(0xe90a, fontFamily: _fontFamily);
  static const IconData garage_outline = IconData(0xe90b, fontFamily: _fontFamily);
  static const IconData garage_car_outline = IconData(0xe90c, fontFamily: _fontFamily);
  static const IconData garage_open_outline = IconData(0xe90d, fontFamily: _fontFamily);
  static const IconData gopuram_outline = IconData(0xe90e, fontFamily: _fontFamily);
  static const IconData home_outline = IconData(0xe90f, fontFamily: _fontFamily);
  static const IconData home_alt_outline = IconData(0xe910, fontFamily: _fontFamily);
  static const IconData home_lg_outline = IconData(0xe911, fontFamily: _fontFamily);
  static const IconData home_lg_alt_outline = IconData(0xe912, fontFamily: _fontFamily);
  static const IconData hospital_outline = IconData(0xe913, fontFamily: _fontFamily);
  static const IconData hospital_alt_outline = IconData(0xe914, fontFamily: _fontFamily);
  static const IconData hospitals_outline = IconData(0xe915, fontFamily: _fontFamily);
  static const IconData hospital_user_outline = IconData(0xe916, fontFamily: _fontFamily);
  static const IconData hotel_outline = IconData(0xe917, fontFamily: _fontFamily);
  static const IconData house_outline = IconData(0xe918, fontFamily: _fontFamily);
  static const IconData house_damage_outline = IconData(0xe919, fontFamily: _fontFamily);
  static const IconData house_day_outline = IconData(0xe91a, fontFamily: _fontFamily);
  static const IconData house_flood_outline = IconData(0xe91b, fontFamily: _fontFamily);
  static const IconData house_night_outline = IconData(0xe91c, fontFamily: _fontFamily);
  static const IconData igloo_outline = IconData(0xe91d, fontFamily: _fontFamily);
  static const IconData industry_outline = IconData(0xe91e, fontFamily: _fontFamily);
  static const IconData industry_alt_outline = IconData(0xe91f, fontFamily: _fontFamily);
  static const IconData kaaba_outline = IconData(0xe920, fontFamily: _fontFamily);
  static const IconData landmark_outline = IconData(0xe921, fontFamily: _fontFamily);
  static const IconData landmark_alt_outline = IconData(0xe922, fontFamily: _fontFamily);
  static const IconData monument_outline = IconData(0xe923, fontFamily: _fontFamily);
  static const IconData mosque_outline = IconData(0xe924, fontFamily: _fontFamily);
  static const IconData place_of_worship_outline = IconData(0xe925, fontFamily: _fontFamily);
  static const IconData school_outline = IconData(0xe926, fontFamily: _fontFamily);
  static const IconData store_outline = IconData(0xe927, fontFamily: _fontFamily);
  static const IconData store_alt_outline = IconData(0xe928, fontFamily: _fontFamily);
  static const IconData archway_solid = IconData(0xe929, fontFamily: _fontFamily);
  static const IconData building_solid = IconData(0xe92a, fontFamily: _fontFamily);
  static const IconData campground_solid = IconData(0xe933, fontFamily: _fontFamily);
  static const IconData car_building_solid = IconData(0xe934, fontFamily: _fontFamily);
  static const IconData chimney_solid = IconData(0xe940, fontFamily: _fontFamily);
  static const IconData church_solid = IconData(0xe941, fontFamily: _fontFamily);
  static const IconData city_solid = IconData(0xe942, fontFamily: _fontFamily);
  static const IconData clinic_medical_solid = IconData(0xe94f, fontFamily: _fontFamily);
  static const IconData container_storage_solid = IconData(0xe950, fontFamily: _fontFamily);
  static const IconData dungeon_solid = IconData(0xe951, fontFamily: _fontFamily);
  static const IconData farm_solid = IconData(0xe952, fontFamily: _fontFamily);
  static const IconData garage_solid = IconData(0xe953, fontFamily: _fontFamily);
  static const IconData garage_car_solid = IconData(0xe954, fontFamily: _fontFamily);
  static const IconData garage_open_solid = IconData(0xe95c, fontFamily: _fontFamily);
  static const IconData gopuram_solid = IconData(0xe963, fontFamily: _fontFamily);
  static const IconData home_solid = IconData(0xe964, fontFamily: _fontFamily);
  static const IconData home_alt_solid = IconData(0xe965, fontFamily: _fontFamily);
  static const IconData home_lg_solid = IconData(0xe966, fontFamily: _fontFamily);
  static const IconData home_lg_alt_solid = IconData(0xe967, fontFamily: _fontFamily);
  static const IconData hospital_solid = IconData(0xe968, fontFamily: _fontFamily);
  static const IconData hospital_alt_solid = IconData(0xe971, fontFamily: _fontFamily);
  static const IconData hospitals_solid = IconData(0xe979, fontFamily: _fontFamily);
  static const IconData hospital_user_solid = IconData(0xe988, fontFamily: _fontFamily);
  static const IconData hotel_solid = IconData(0xe992, fontFamily: _fontFamily);
  static const IconData house_solid = IconData(0xe99b, fontFamily: _fontFamily);
  static const IconData house_damage_solid = IconData(0xe99c, fontFamily: _fontFamily);
  static const IconData house_day_solid = IconData(0xe99d, fontFamily: _fontFamily);
  static const IconData house_flood_solid = IconData(0xe99e, fontFamily: _fontFamily);
  static const IconData house_night_solid = IconData(0xe99f, fontFamily: _fontFamily);
  static const IconData igloo_solid = IconData(0xe9a6, fontFamily: _fontFamily);
  static const IconData industry_solid = IconData(0xe9a7, fontFamily: _fontFamily);
  static const IconData industry_alt_solid = IconData(0xe9a8, fontFamily: _fontFamily);
  static const IconData kaaba_solid = IconData(0xe9ac, fontFamily: _fontFamily);
  static const IconData landmark_solid = IconData(0xe9ad, fontFamily: _fontFamily);
  static const IconData landmark_alt_solid = IconData(0xe9ae, fontFamily: _fontFamily);
  static const IconData monument_solid = IconData(0xe9af, fontFamily: _fontFamily);
  static const IconData mosque_solid = IconData(0xe9b0, fontFamily: _fontFamily);
  static const IconData place_of_worship_solid = IconData(0xe9b1, fontFamily: _fontFamily);
  static const IconData school_solid = IconData(0xe9b2, fontFamily: _fontFamily);
  static const IconData store_solid = IconData(0xe9b3, fontFamily: _fontFamily);
  static const IconData store_alt_solid = IconData(0xe9b4, fontFamily: _fontFamily);
  static const IconData synagogue_solid = IconData(0xe9b5, fontFamily: _fontFamily);
  static const IconData torii_gate_solid = IconData(0xe9b6, fontFamily: _fontFamily);
  static const IconData university_solid = IconData(0xe9b7, fontFamily: _fontFamily);
  static const IconData vihara_solid = IconData(0xe9b8, fontFamily: _fontFamily);
  static const IconData warehouse_solid = IconData(0xe9b9, fontFamily: _fontFamily);
  static const IconData synagogue_outline = IconData(0xe9ba, fontFamily: _fontFamily);
  static const IconData torii_gate_outline = IconData(0xe9bb, fontFamily: _fontFamily);
  static const IconData university_outline = IconData(0xe9bc, fontFamily: _fontFamily);
  static const IconData vihara_outline = IconData(0xe9bd, fontFamily: _fontFamily);
  static const IconData warehouse_outline = IconData(0xe9be, fontFamily: _fontFamily);
  static const IconData warehouse_alt_outline = IconData(0xe9bf, fontFamily: _fontFamily);
  static const IconData warehouse_alt_solid = IconData(0xe9c0, fontFamily: _fontFamily);
}

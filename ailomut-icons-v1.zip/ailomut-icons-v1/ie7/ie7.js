/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'ailomut-icons\'">' + entity + '</span>' + html;
	}
	var icons = {
		'am-archway-outline': '&#xe900;',
		'am-building-outline': '&#xe901;',
		'am-campground-outline': '&#xe902;',
		'am-car-building-outline': '&#xe903;',
		'am-chimney-outline': '&#xe904;',
		'am-church-outline': '&#xe905;',
		'am-city-outline': '&#xe906;',
		'am-clinic-medical-outline': '&#xe907;',
		'am-container-storage-outline': '&#xe908;',
		'am-dungeon-outline': '&#xe909;',
		'am-farm-outline': '&#xe90a;',
		'am-garage-outline': '&#xe90b;',
		'am-garage-car-outline': '&#xe90c;',
		'am-garage-open-outline': '&#xe90d;',
		'am-gopuram-outline': '&#xe90e;',
		'am-home-outline': '&#xe90f;',
		'am-home-alt-outline': '&#xe910;',
		'am-home-lg-outline': '&#xe911;',
		'am-home-lg-alt-outline': '&#xe912;',
		'am-hospital-outline': '&#xe913;',
		'am-hospital-alt-outline': '&#xe914;',
		'am-hospitals-outline': '&#xe915;',
		'am-hospital-user-outline': '&#xe916;',
		'am-hotel-outline': '&#xe917;',
		'am-house-outline': '&#xe918;',
		'am-house-damage-outline': '&#xe919;',
		'am-house-day-outline': '&#xe91a;',
		'am-house-flood-outline': '&#xe91b;',
		'am-house-night-outline': '&#xe91c;',
		'am-igloo-outline': '&#xe91d;',
		'am-industry-outline': '&#xe91e;',
		'am-industry-alt-outline': '&#xe91f;',
		'am-kaaba-outline': '&#xe920;',
		'am-landmark-outline': '&#xe921;',
		'am-landmark-alt-outline': '&#xe922;',
		'am-monument-outline': '&#xe923;',
		'am-mosque-outline': '&#xe924;',
		'am-place-of-worship-outline': '&#xe925;',
		'am-school-outline': '&#xe926;',
		'am-store-outline': '&#xe927;',
		'am-store-alt-outline': '&#xe928;',
		'am-archway-solid': '&#xe929;',
		'am-building-solid': '&#xe92a;',
		'am-campground-solid': '&#xe933;',
		'am-car-building-solid': '&#xe934;',
		'am-chimney-solid': '&#xe940;',
		'am-church-solid': '&#xe941;',
		'am-city-solid': '&#xe942;',
		'am-clinic-medical-solid': '&#xe94f;',
		'am-container-storage-solid': '&#xe950;',
		'am-dungeon-solid': '&#xe951;',
		'am-farm-solid': '&#xe952;',
		'am-garage-solid': '&#xe953;',
		'am-garage-car-solid': '&#xe954;',
		'am-garage-open-solid': '&#xe95c;',
		'am-gopuram-solid': '&#xe963;',
		'am-home-solid': '&#xe964;',
		'am-home-alt-solid': '&#xe965;',
		'am-home-lg-solid': '&#xe966;',
		'am-home-lg-alt-solid': '&#xe967;',
		'am-hospital-solid': '&#xe968;',
		'am-hospital-alt-solid': '&#xe971;',
		'am-hospitals-solid': '&#xe979;',
		'am-hospital-user-solid': '&#xe988;',
		'am-hotel-solid': '&#xe992;',
		'am-house-solid': '&#xe99b;',
		'am-house-damage-solid': '&#xe99c;',
		'am-house-day-solid': '&#xe99d;',
		'am-house-flood-solid': '&#xe99e;',
		'am-house-night-solid': '&#xe99f;',
		'am-igloo-solid': '&#xe9a6;',
		'am-industry-solid': '&#xe9a7;',
		'am-industry-alt-solid': '&#xe9a8;',
		'am-kaaba-solid': '&#xe9ac;',
		'am-landmark-solid': '&#xe9ad;',
		'am-landmark-alt-solid': '&#xe9ae;',
		'am-monument-solid': '&#xe9af;',
		'am-mosque-solid': '&#xe9b0;',
		'am-place-of-worship-solid': '&#xe9b1;',
		'am-school-solid': '&#xe9b2;',
		'am-store-solid': '&#xe9b3;',
		'am-store-alt-solid': '&#xe9b4;',
		'am-synagogue-solid': '&#xe9b5;',
		'am-torii-gate-solid': '&#xe9b6;',
		'am-university-solid': '&#xe9b7;',
		'am-vihara-solid': '&#xe9b8;',
		'am-warehouse-solid': '&#xe9b9;',
		'am-synagogue-outline': '&#xe9ba;',
		'am-torii-gate-outline': '&#xe9bb;',
		'am-university-outline': '&#xe9bc;',
		'am-vihara-outline': '&#xe9bd;',
		'am-warehouse-outline': '&#xe9be;',
		'am-warehouse-alt-outline': '&#xe9bf;',
		'am-warehouse-alt-solid': '&#xe9c0;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/am-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
